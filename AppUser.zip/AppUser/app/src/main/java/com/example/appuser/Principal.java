package com.example.appuser;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationRequest;
import android.os.Bundle;
import android.widget.Toast;


import com.example.clases.Servicio;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Principal extends AppCompatActivity {

    DatabaseReference dbr;
    public LocationManager locationManager;
    LocationRequest lr;
    AlertDialog alert = null;
    //private Marker marcador;
    public String nombre = "";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            nombre = extras.getString("clave");
            //startService(new Intent(getApplicationContext(),SegundoPlano.class));
        }

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        /*ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_BACKGROUND_LOCATION}, 0);*/


        dbr = FirebaseDatabase.getInstance().getReference();

        verificarPermiso();

    }

    public void verificarPermiso(){
        if(ContextCompat.checkSelfPermission(getApplicationContext(),Manifest.permission.ACCESS_COARSE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this, "No se han aceptado los permisos!", Toast.LENGTH_SHORT).show();
            finish();
        }else{
            if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                AlertNoGPS();
            }else{
                Intent service = new Intent(getApplicationContext(),Servicio.class);
                service.putExtra("nombre",nombre);
                startForegroundService(service);
            }

        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        stopService(new Intent(this, Servicio.class));
        locationManager.removeUpdates(locListener);

    }
/*
    @Override
    protected void onResume() {
        super.onResume();
        ubicacion();
    }*/

/*
    @Override public void onPause() {
        if (isApplicationSentToBackground(this)){

            ubicacion();
            Toast.makeText(this, "pause", Toast.LENGTH_SHORT).show();
        }
        super.onPause();
    }

    public boolean isApplicationSentToBackground(final Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(1);
        if (!tasks.isEmpty()) {
            ComponentName topActivity = tasks.get(0).topActivity;
            if (!topActivity.getPackageName().equals(context.getPackageName())) {
                return true;
            }
        }
        return false;
    }

*/

    //mensaje cunado el GPS esta desactivado
    public void AlertNoGPS(){
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("El sistema GPS esta desactivado, ¿Desea activarlo?")
                .setCancelable(false)
                .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        dialog.cancel();
                        Toast.makeText(Principal.this, "El GPS esta desactivado", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
        alert = builder.create();
        alert.show();
    }

    //verificando si los permisos de ubicacion fueron permitidos
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        AlertNoGPS();
                    }else{
                        Toast.makeText(this, "todo bien", Toast.LENGTH_SHORT).show();
                        //ubicacion();
                    }
                } else {
                    Toast.makeText(this, "Permiso Denegado | Es Necesario Activar el Permiso", Toast.LENGTH_SHORT).show();
                    //AlertNoGPS();
                    finish();
                }
                return;
            }
        }

    }


    public void ubicacion(){
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        //Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000 , 0 , (LocationListener) locListener);
    }
    LocationListener locListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            //obtener fecha
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
            Date date = new Date();
            String fecha = dateFormat.format(date);

            //obtener hora
            SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
            Date curDate = new Date(System.currentTimeMillis());
            String hora = formatter.format(curDate);

            Map<String,Object> latLang = new HashMap<>();
            latLang.put("latitud",location.getLatitude());
            latLang.put("longitud",location.getLongitude());
            latLang.put("fecha",fecha);
            latLang.put("hora",hora);
            latLang.put("usuario",nombre);

            dbr.child("usuarios").child(nombre).updateChildren(latLang);

        }

        @Override
        public void onStatusChanged(String s, int i, Bundle bundle) {

        }

        @Override
        public void onProviderEnabled(String s) {

        }

        @Override
        public void onProviderDisabled(String s) {

        }
    };



}